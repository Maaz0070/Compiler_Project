## g++ required to make program, or change CC in makefile

## The default test file name is 'masterTestCase.txt', which is used to construct the Scanner in main() of main.cpp line 22
# To update the test text, please change the agurment of line #22 in main.cpp to the name of the new test file
 						Scanner scanner("test-in.txt");
# Instructions:

1. make
2. ./output
3. Scanner output will be printed to stdout and 'scannerOutput.txt'
